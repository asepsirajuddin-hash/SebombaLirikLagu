# Sebomba Lirik Lagu — APK dari HP

Paket ini adalah proyek Android offline. Tidak memerlukan internet saat aplikasi dipakai.
Fitur: 100 lagu awal, pencarian, filter, tambah, edit, hapus, backup dan pulihkan.

## Cara membuat APK tanpa laptop
1. Buat akun GitHub dari HP.
2. Buat repository baru.
3. Upload seluruh isi folder proyek ini.
4. Buka tab **Actions** lalu jalankan workflow **Build APK**.
5. Setelah selesai, buka hasil workflow dan unduh artifact **Sebomba-Lirik-Lagu-APK**.
6. Ekstrak artifact dan instal file APK di HP.

Lirik starter di aplikasi adalah lirik original. Untuk lagu berhak cipta, masukkan lirik yang Anda punya hak untuk gunakan.
